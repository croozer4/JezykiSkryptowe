<html>
    <body>

        <form action="dozrobienia3logika.php" method="post">
            Nazwa zespołu: <input type="text" name="zespol"><br>
            <input type="submit">
        </form>

    </body>
</html>
