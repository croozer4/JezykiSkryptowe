<html>
    <body>

        <form action="dozrobienia4logika.php" method="post">
            Nazwa płyty: <input type="text" name="nazwa_plyty"><br>
            Nowa nazwa płyty <input type="text" name="nowa_nazwa_plyty"><br> 
            <input type="submit">
        </form>

    </body>
</html>
