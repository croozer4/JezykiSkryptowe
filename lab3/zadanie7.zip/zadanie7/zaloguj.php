<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>

    <h3>Zaloguj się!</h3>

    <form action="loguj.php" method="post">

    <label for="login">Login:</label>
    <input type="text" id="login" name="login"><br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password"><br>

    <input type="submit">

    </form>

    </body>
</html>